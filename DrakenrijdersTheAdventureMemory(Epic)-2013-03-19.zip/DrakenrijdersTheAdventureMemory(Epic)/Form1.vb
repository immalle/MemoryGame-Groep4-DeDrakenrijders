﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Label1.SendToBack()
    End Sub

    Sub Kaders(xy As Integer)

        For i = 0 To xy
            For j = 0 To xy
                Dim kaart As PictureBox
                kaart.Size = New Size(50, 90)
                kaart.Location = New Point(50 + xy * 65, 40 + xy * 110)

                Me.Controls.Add(kaart)

            Next
        Next
    End Sub

    Private Sub Easyrdb_CheckedChanged(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Label1_Click(sender As System.Object, e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Godlikerdb_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles Godlikerdb.CheckedChanged
        Label1.BringToFront()
    End Sub
End Class
