﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Easyrdb As System.Windows.Forms.RadioButton
        Me.Godlikerdb = New System.Windows.Forms.RadioButton()
        Me.Impossiblerdb = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Easyrdb = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'Easyrdb
        '
        Easyrdb.AutoSize = True
        Easyrdb.Location = New System.Drawing.Point(518, 239)
        Easyrdb.Name = "Easyrdb"
        Easyrdb.Size = New System.Drawing.Size(48, 17)
        Easyrdb.TabIndex = 0
        Easyrdb.TabStop = True
        Easyrdb.Text = "Easy"
        Easyrdb.UseVisualStyleBackColor = True
        AddHandler Easyrdb.CheckedChanged, AddressOf Me.Easyrdb_CheckedChanged
        '
        'Godlikerdb
        '
        Me.Godlikerdb.AutoSize = True
        Me.Godlikerdb.Location = New System.Drawing.Point(518, 262)
        Me.Godlikerdb.Name = "Godlikerdb"
        Me.Godlikerdb.Size = New System.Drawing.Size(61, 17)
        Me.Godlikerdb.TabIndex = 1
        Me.Godlikerdb.TabStop = True
        Me.Godlikerdb.Text = "Godlike"
        Me.Godlikerdb.UseVisualStyleBackColor = True
        '
        'Impossiblerdb
        '
        Me.Impossiblerdb.AutoSize = True
        Me.Impossiblerdb.Location = New System.Drawing.Point(518, 285)
        Me.Impossiblerdb.Name = "Impossiblerdb"
        Me.Impossiblerdb.Size = New System.Drawing.Size(74, 17)
        Me.Impossiblerdb.TabIndex = 2
        Me.Impossiblerdb.TabStop = True
        Me.Impossiblerdb.Text = "Impossible"
        Me.Impossiblerdb.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(518, 239)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 63)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Label1"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(517, 177)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 39)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(656, 384)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Impossiblerdb)
        Me.Controls.Add(Me.Godlikerdb)
        Me.Controls.Add(Easyrdb)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Godlikerdb As System.Windows.Forms.RadioButton
    Friend WithEvents Impossiblerdb As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
